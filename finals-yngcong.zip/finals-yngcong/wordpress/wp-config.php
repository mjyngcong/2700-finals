<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'finals-yngcong' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'q%]}mZ-Ph!XOB?O*G2Lx4z_0v`b20t|~Hx%^1TmKuB5=wXAO9&dDptE^JU%h]F2I' );
define( 'SECURE_AUTH_KEY',  ')l(<-ZQ4X{f?X*q[UIM[;?FnNovH[1ZC(~?%#&KVD!GRX2B0xFf)Sj$-A{V US34' );
define( 'LOGGED_IN_KEY',    'bA5([ jo~Ku@T?H6y_fsHe.<X|m!oMtrpQmM^)X9m5A1,:jcFTj;sAvCKOIp5U&Z' );
define( 'NONCE_KEY',        'dGF(}{_N_I=D|LEq~7hBSzw8UTv+2m;VhySzhLB~v=_PO%dhPLV>=qSJd)RaO2Mn' );
define( 'AUTH_SALT',        '!m}&$!~B.wkx<zq|Cp-x5k7R.pKqc4Y[AUV(7iQrBv:*+}Fo-cv*L/pAD[i3Z:8`' );
define( 'SECURE_AUTH_SALT', '|tz>?SF}}A+_f6UhMp|vs!7X89S%i8&fPxs(jx3H.h6xrfC!6&0LSDJj1K$|Qh{c' );
define( 'LOGGED_IN_SALT',   'JpCe7?s9MtxZCv3]NTP2DJpFpsTlq#k&yb~$l$)Y`R&Ae V4*LG})L}uYBJJ8$<(' );
define( 'NONCE_SALT',       'Du4z2Jf/qhj4=1O 8,v~%Jw2JE:Q,+9U#d1rQNVeYerOrN8pdCuI@;WL$cGcR/u_' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
